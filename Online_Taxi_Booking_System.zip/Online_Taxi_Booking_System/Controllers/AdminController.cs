﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Online_Taxi_Booking_System.Models;
using Online_Taxi_Booking_System;

namespace Online_Taxi_Booking_System.Controllers
{
    public class AdminController : Controller
    {
        Training_20March_CloudChennaiEntities db = new Training_20March_CloudChennaiEntities();
        Training_20March_CloudChennaiEntities1 fb = new Training_20March_CloudChennaiEntities1();

        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AdminRoles()
        {
            return View();
        }

        public ActionResult EmployeeRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult EmployeeRegister(EmployeeLogin login)
        {
            db.EmployeeLogins.Add(login);
            db.SaveChanges();

            return RedirectToAction("AdminRoles", "Admin");
        }

        public ActionResult ViewFeedback()
        {
            List<Feedback> feedback = fb.Feedbacks.ToList();
            //var feedback = new List<Feedback>();
            var query = from Feedback s in feedback select s;
            return View(query);                        
        }

        public ActionResult ChangePassword()
        {
            
            Response.Write("Password Changed Succesfully");
            return View();
        }
    }
}