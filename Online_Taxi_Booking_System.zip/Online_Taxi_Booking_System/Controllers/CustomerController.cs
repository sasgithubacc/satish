﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Online_Taxi_Booking_System.Models;

namespace Online_Taxi_Booking_System.Controllers
{
    
    public class CustomerController : Controller
    {
        private Training_20March_CloudChennaiEntities db = new Training_20March_CloudChennaiEntities();
        private Training_20March_CloudChennaiEntities1 fb = new Training_20March_CloudChennaiEntities1();

        CustomerLogin login = new CustomerLogin();

        // GET: Customer
        public ActionResult CustomerHome()
        {
            return View();
        }

        public ActionResult CustomerAdd()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CustomerAdd(CustomerLogin login)
        {
            db.CustomerLogins.Add(login);
            db.SaveChanges();
            return RedirectToAction("CustomerHome","Customer");
        }
        

        public ActionResult CustomerLogin()
        {
            return View();
        }

        [HttpPost]

        public ActionResult CustomerLogin(CustomerLogin login)

        {

            if (ModelState.IsValid)

            {

                //DBEntity db = new DBEntity();

                var user = (from CustomerLogin cl in db.CustomerLogins

                            where cl.CustomerName == login.CustomerName && cl.Password == login.Password 

                            select new

                            {
                                cl.CustomerName

                            }).ToList();

                if (user.FirstOrDefault() != null)

                {

                    Session["CustomerName"] = user.FirstOrDefault().CustomerName;



                    return Redirect("/Customer/CustomerRoles");

                }

                else

                {

                    ModelState.AddModelError("", "Invalid login credentials.");

                }

            }

            return View(login);

        }



        public ActionResult CustomerRoles()
        {
            return View();
        }

        public ActionResult Feedback()
        {
            return View();
        }

        [HttpPost]
        public ActionResult FeedBack(Feedback feedback)
        {
            fb.Feedbacks.Add(feedback);
            fb.SaveChanges();
            Response.Write("Feedback saved Successfully");
            return View();
        }

        public ActionResult Booking()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Booking(Booking book)
        {
            db.Bookings.Add(book);
            db.SaveChanges();
            Response.Write("Booked Successfully");
            return View();
        }


    }
}