﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Online_Taxi_Booking_System.Startup))]
namespace Online_Taxi_Booking_System
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
